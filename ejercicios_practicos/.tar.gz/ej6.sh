#!/bin/bash

read -p "palabra: " pal

echo "$pal" >> fichero.txt

cat fichero.txt
