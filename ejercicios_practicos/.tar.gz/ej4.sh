#!/bin/bash

read -p "numero 1:" n1
read -p "numero 2:" n2

echo " $n1 $n2 " 
