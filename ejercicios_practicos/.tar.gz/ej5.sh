#!/bin/bash

read -p "numero 1:" n1
read -p "numero 2:" n2

suma="$((n1+n2))"
media="$((suma/2))"
echo " $media " 
