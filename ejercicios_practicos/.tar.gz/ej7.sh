#!/bin/bash
# tar -cvzf date_etc.tar.gz ./etc/cosas2

dia=date +"%d/%m/%Y"


read -p "Que directorio: " dir

print "$dia_$dir.tar.gz"

tar -cvzf "$DIA_$dir.tar.gz"  ./"$dir"
