#!/bin/bash


touch fichero.txt

ls -a etc  > fichero.txt


cat fichero.txt
